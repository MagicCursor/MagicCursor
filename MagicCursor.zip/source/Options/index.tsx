import * as React from 'react';
import ReactDOM from 'react-dom';

import Options from './Options';

ReactDOM.render(<Options />, document.getElementById('options-root'));
